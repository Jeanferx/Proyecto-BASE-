import { Component } from '@angular/core';

@Component({
  selector: 'app-principal',
  templateUrl: './principal.html',
  styleUrls: ['./principal.css'], // <- corregido
})
export class Principal { }
