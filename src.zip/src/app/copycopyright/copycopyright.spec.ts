import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Copycopyright } from './copycopyright';

describe('Copycopyright', () => {
  let component: Copycopyright;
  let fixture: ComponentFixture<Copycopyright>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Copycopyright]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Copycopyright);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
