import { Component } from '@angular/core';

@Component({
  selector: 'app-copycopyright',
  imports: [],
  templateUrl: './copycopyright.html',
  styleUrl: './copycopyright.css',
})
export class Copycopyright {

}
