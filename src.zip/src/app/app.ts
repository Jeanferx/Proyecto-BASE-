import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Menu } from './menu/menu';
import { Login } from './login/login';
import { Copycopyright } from './copycopyright/copycopyright';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, Menu, Login, Copycopyright],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {
  showLogin = false;

  onLoginClicked() {
    this.showLogin = true; // muestra el login al hacer clic
  }
}
